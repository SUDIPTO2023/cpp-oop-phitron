#include <bits/stdc++.h>
using namespace std;
int main()
{

    // string s="sudipto Raja";
//    string s("sudipto Raja");//direct constructor call
   // string s("sudipto Raja",7);//7 index er agey porjonto
//    string a="sudipto Raja";
//    string s(a,7);//7 number index thekey last porjonto print
      string s(30,'R');//30 ta  R print korbey
    cout<<s<<endl;






    return 0;
}