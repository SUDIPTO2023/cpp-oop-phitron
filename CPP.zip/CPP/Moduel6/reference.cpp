 #include<bits/stdc++.h>
using namespace std;
void fun(string &s)//reference pathaley main function o change hoi jai
{
    s="raja";
}
int main()
{
  string s="sudipto";
  fun(s);
  cout<<s<<endl;
    return 0;
}