 #include<bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    cin>>s;
    // for (int i = 0; i < s.size(); i++) //GENERAL FORLOOP
    // {
    //     cout<<s[i]<<endl;
    // }


    //range based for loop only for character not for index

    for(char c:s)
    {
        cout<<c<<endl;
    }

    return 0;
}