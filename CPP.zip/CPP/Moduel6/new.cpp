 #include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int a[n];
    for (int i = 0; i < n; i++)
    {
        cin>>a[i];
    }
    int temp=0;
    int i=0;
    int j=n-1;
    while (i<j)
    {
        if (a[i]!=a[j])
        {
            temp++;
            break;
        }
        i++;
        j--;
        
    }
    if (temp==0)
    {
        cout<<"true";
    }else
    {
        cout<<"false";
    }
    
    
    
    

    return 0;
}