#include <bits/stdc++.h>
using namespace std;
void fun(stringstream &ss) // here string class cant work with pointer its work reference
{
    string word;
    if (ss >> word)
    {
        fun(ss);
        cout << word << endl;
    }
}
int main()
{
    string s;
    getline(cin, s);
    stringstream ss(s);
    // string word;
    // int cnt=0;
    // while (ss>>word)
    // {
    //     cnt++;
    //    cout<<word<<endl;
    // }
    // cout<<cnt;
    fun(ss);

    return 0;
}