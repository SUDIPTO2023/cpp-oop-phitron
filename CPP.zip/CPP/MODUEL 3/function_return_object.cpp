#include <bits/stdc++.h>
using namespace std;
class Student
{
public:
    int roll;
    int cls;
    double gpa;
    Student(int roll, int cls, double gpa)
    {
        this->roll = roll;
        this->cls = cls;
        this->gpa = gpa;
    }
};
Student fun()
{

    Student sudipto(25, 9, 3.51);
    return sudipto;
}
int main()
{
    Student sudipto = fun();
    cout<<sudipto.cls<<" "<<sudipto.roll<<" "<<sudipto.gpa<<endl;

    return 0;
}