#include <bits/stdc++.h>
using namespace std;
class Student
{
public:
    char name[100];
    int roll;
    double cgpa;
};
int main()
{
    Student s1, s2;//s1 & s2 is a object of class or variable of class
    cin.getline(s1.name, 100);
    cin >> s1.roll;
    cin >> s1.cgpa;
    getchar();
    cin.getline(s2.name, 100);
    
    cin >> s2.roll >> s2.cgpa;
    cout << s1.name << endl;
    cout << s1.roll << endl;
    cout << s1.cgpa << endl;
    cout << s2.name << endl;
    cout << s2.roll << endl;
    cout << s2.cgpa << endl;

    return 0;
}