#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        string s;
        cin >> s;
        int sum1 = 0, sum2 = 0;
        for (int i = 0; i < s.size() - 3; i++)
        {
            sum1 += s[i];
        }
        // cout<<sum1;

        for (int i= s.size() - 3; i < s.size(); i++)
        {
            sum2 += s[i];
        }

        if (sum1 == sum2)
        {
            cout << "YES";
        }
        else
        {
            cout << "NO";
        }
        cout << endl;
    
    }

    return 0;
}