 #include<bits/stdc++.h>
using namespace std;
int main()
{   

    string s;
        cin >> s;
        int sum1 = 0, sum2 = 0;
        for (int i = 0; i < s.size() - 3; i++)
        {
            sum1 += s[i]-'0';
        }
         cout<<sum1;

        for (int i= s.size() - 3; i < s.size(); i++)
        {
            sum2 += s[i];
        }
         
    return 0;
}