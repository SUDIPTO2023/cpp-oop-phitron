 #include<bits/stdc++.h>
using namespace std;
int main()
{
 string s;
 getline(cin,s);
 stringstream s1(s);
 string word,sp="";
 while (s1>>word)
 {
    cout<<sp;
    for ( int i = word.size()-1; i>=0; i--)
    {
        cout<<word[i];
        
    }
      sp=" ";
    
    
    
 }
 

    return 0;
}