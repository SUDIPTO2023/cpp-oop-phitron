 #include<bits/stdc++.h>
using namespace std;
int main()
{

 string s;
 getline(cin,s);
 stringstream s1(s);
 string word;
 int cnt=0;
 while (s1>>word)
 {
    if ((word[0]>='A'&&word[0]<='z')||(word[0]>='a'&& word[0]<='z'))
    {
        cnt++;
    }
    
    
 }
 cout<<cnt<<endl;




 return 0;

}
