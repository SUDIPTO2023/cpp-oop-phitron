 #include<bits/stdc++.h>
using namespace std;
int main()
{
   char c[100];
   cin>>c;
   int i=0;
   int j=strlen(c);
   while (i<j)
   {
    c[i]=c[j];
    
    i++;
    j--;
   }
    
   cout<<c<<endl;
   
   
   
    

    return 0;
}