cout<<*s.begin()<<endl;
    // cout<<*(s.end()-1)<<endl;
