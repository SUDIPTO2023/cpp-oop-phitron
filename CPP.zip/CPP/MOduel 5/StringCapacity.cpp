 #include<bits/stdc++.h>
using namespace std;
int main()
{
    // string s="raja";
    // cout<<s.size()<<endl;//lenght function for string
    // string s="sudipto_kumar_chakrabarty_raja";
    // cout<<s.capacity()<<endl;//autometic capacityj increase
    // cout<<s.size()<<endl;
    // string s="Raja";
    //  cout<<s<<endl;
    //  s.clear();//its not return anything
    //  cout<<s.size()<<endl;
    //  cout<<s<<endl;
    // string s="sudipto";
    // s.clear();
    
    // if (s.empty()==true)
    // {
    //     cout<<"empty";
    // }else
    // {
    //     cout<<"not empty";
    // }
    // string s="sudipto_raja";
    // s.resize(7);//resize it will be size increase or decrease
    
    // cout<<s<<endl;
    // s.resize(19,'x');
    // cout<<s;
    
    



     return 0;
}