#include<bits/stdc++.h>
using namespace std;
int main()
{
    string s="RajA";
    // cout<<s[0]<<endl;//use
    // cout<<s.at(0)<<endl;//element access using function


  //last element access n-1;
    cout<<s[s.size()-1]<<endl;
    cout<<s.back()<<endl;//last element access using function,important



    return 0;
}