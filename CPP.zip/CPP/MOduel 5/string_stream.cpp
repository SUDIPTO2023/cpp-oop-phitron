 #include<bits/stdc++.h>
using namespace std;
int main()
{
  string s;
  getline(cin,s);
  stringstream s1(s);//or s1<<s;
  
  string word;
  while (s1>>word)
  {
    cout<<word<<endl;
  }
  

    return 0;
}