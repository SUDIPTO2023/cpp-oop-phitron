#include<bits/stdc++.h>
using namespace std;
int main()
{
  char c;
  cin>>c;
   
  if (int (c)>=48 && int (c)<=57)
  {
    cout<<"IS DIGIT"<<endl;
  }
  else if (int (c)>=65 && int (c)<=90)
  {
    cout<<"ALPHA"<<endl;
    cout<<"IS CAPITAL"<<endl;
  }else
  {
    cout<<"ALPHA"<<endl;
    cout<<"IS SMALL"<<endl;
  }
  
  
  




    return 0;
}